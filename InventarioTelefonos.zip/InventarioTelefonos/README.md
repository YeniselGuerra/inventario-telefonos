# Inventario de Teléfonos — APK Android

Aplicación Android (Kotlin) que **recoge automáticamente los datos técnicos de un teléfono** y **envía la ficha completa por SMS** a un número de destino configurable en la propia app.

Pensada para el inventario corporativo de teléfonos: un formulario con 17 campos, la mayoría autollenados por el sistema, y el envío en un formato compacto que una aplicación receptora puede interpretar automáticamente.

---

## 1. Qué hace la app

1. Al abrirse, **autollena los campos automáticos** (marca, modelo, versión de Android, WiFi IP, SIM IP, ¿acceso a Internet?, número de teléfono, IMEI y MAC cuando Android lo permite).
2. El usuario completa los datos que solo la empresa conoce (trabajador, CI, cargo, tipo, plan, PIN/PUK).
3. El botón **“Enviar ficha por SMS”** muestra una vista previa con la cantidad de SMS que ocupará y, al confirmar, lo envía automáticamente al número configurado.
4. Botones adicionales: abrir la app de SMS con el mensaje ya redactado (no requiere permisos) y copiar el mensaje al portapapeles.
5. **Configuración (⚙):** número de teléfono de destino **editable desde la propia app** y elección del formato del mensaje.
6. Lo escrito se guarda como borrador local: si se cierra la app no se pierde nada.

## 2. Campos del formulario

| # | Campo | Origen | Nota |
|---|-------|--------|------|
| 1 | Trabajador | Manual | |
| 2 | CI | Manual | |
| 3 | Cargo | Manual | |
| 4 | Tipo (Corporativo / Privado) | Manual | Lista desplegable |
| 5 | Marca | **Automático** | `Build.MANUFACTURER` |
| 6 | Modelo | **Automático** | `Build.MODEL` |
| 7 | Versión de Android | **Automático** | Ej.: `Android 10 (API 29)` |
| 8 | No. Teléfono | **Automático** | Depende del operador; si viene vacío se escribe a mano |
| 9 | IMEI | **Automático con permiso** | Solo Android 9 o anterior; en 10+ se escribe a mano (marcar `*#06#`) |
| 10 | MAC Address | **Automático con permiso** | Solo Android 9 o anterior; en 10+ el sistema devuelve una MAC aleatoria por red |
| 11 | WiFi IP Address | **Automático** | IP de la interfaz `wlan0` |
| 12 | SIM IP Address | **Automático** | IP de la interfaz de datos móviles (`rmnet…`) |
| 13 | ¿Acceso a Internet? | **Automático** | SI / NO según el estado real de la red |
| 14 | Minutos del plan | Manual | Lo conoce el operador |
| 15 | Megas del plan | Manual | Lo conoce el operador |
| 16 | SIM PIN | Manual | **Nunca** es legible por ninguna app |
| 17 | SIM PUK | Manual | **Nunca** es legible por ninguna app |

## 3. Formato del SMS

### Compacto (recomendado, es el predeterminado)

Una sola línea con pares `CLAVE:VALOR` separados por `|`:

```
INV|TRAB:Juan Pérez|CI:88031512345|CARGO:Especialista|TIPO:Corporativo|MARCA:samsung|MODELO:SM-A015M|ANDV:Android 10 (API 29)|TEL:53123456|IMEI:356938035643809|MAC:AA:BB:CC:DD:EE:FF|WIP:192.168.1.45|SIP:10.20.30.40|NET:SI|MIN:600|MB:4096|PIN:1234|PUK:12345678
```

Tabla de claves (útil para la aplicación receptora):

| Clave | Campo | Clave | Campo |
|-------|-------|-------|-------|
| `TRAB` | Trabajador | `IMEI` | IMEI |
| `CI` | CI | `MAC` | MAC Address |
| `CARGO` | Cargo | `WIP` | WiFi IP |
| `TIPO` | Tipo | `SIP` | SIM IP |
| `MARCA` | Marca | `NET` | Internet (SI/NO) |
| `MODELO` | Modelo | `MIN` | Minutos del plan |
| `ANDV` | Versión Android | `MB` | Megas del plan |
| `TEL` | No. Teléfono | `PIN` | SIM PIN |
| | | `PUK` | SIM PUK |

Para interpretarlo: los mensajes que empiezan por `INV|` se parten por `|`; cada trozo a partir del primero es `CLAVE:VALOR`. Los valores no contienen `|` ni saltos de línea (la app los sustituye), así que el análisis nunca falla.

### Detallado (opcional, para leerlo una persona)

```
INV - Inventario de teléfono
Trabajador: Juan Pérez
CI: 88031512345
Cargo: Especialista
...
```

## 4. Cómo compilar el APK

### Opción A — Android Studio (recomendada)

1. Instale **Android Studio Electric Eel (2022.1.1) o posterior** (incluye el JDK necesario).
2. **File → Open** y seleccione la carpeta `InventarioTelefonos`.
3. Espere a que termine la sincronización de Gradle (la primera vez descarga dependencias; necesita Internet).
4. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
5. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B — Línea de comandos

Requisitos: JDK 11 o 17 y conectividad para descargar Gradle 7.6.4 y las librerías.

```bash
cd InventarioTelefonos
./gradlew assembleDebug        # Linux/Mac
gradlew.bat assembleDebug      # Windows
```

El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción C — Compilar online gratis con GitHub Actions (sin instalar nada)

El proyecto ya incluye `.github/workflows/build-apk.yml`: GitHub compila el APK en sus servidores y lo publica para descargar.

1. Cree una cuenta gratuita en github.com (si no tiene).
2. **New repository** → nombre `inventario-telefonos` → visibilidad **Public** → **Create repository** (sin README).
3. En el repositorio, pulse **“uploading an existing file”** (o **Add file → Upload files**) y arrastre el archivo `InventarioTelefonos.zip` (el que trae la carpeta `.github` incluida) → **Commit changes**.
4. Abra la pestaña **Actions**: la compilación “Compilar APK” arranca sola y tarda entre 5 y 15 minutos.
5. Entre en la ejecución terminada (✔ verde) y baje a la sección **Artifacts**: descargue `InventarioTelefonos-apk` — es un ZIP que contiene `InventarioTelefonos.apk`.
6. Pase el APK al teléfono e instale (sección 5).

Notas: los repositorios públicos compilan gratis e ilimitado; un repositorio privado también sirve (2000 minutos/mes gratis, esta compilación usa ~10). Si la compilación falla (✘ roja), entre en la ejecución, revise el paso con error y copie el mensaje para revisarlo.

### Compatibilidad de versiones

| Componente | Versión usada |
|------------|---------------|
| Gradle | 7.6.4 (el wrapper lo descarga solo) |
| Android Gradle Plugin | 7.4.2 |
| Kotlin | 1.8.22 |
| compileSdk / targetSdk | 33 |
| minSdk | 21 (Android 5.0 en adelante) |

Si su Android Studio es más antiguo que Electric Eel, baje en `build.gradle` (raíz) el plugin a `7.2.2` y en `gradle/wrapper/gradle-wrapper.properties` la distribución a `gradle-7.3.3-bin.zip`; además agregue `package="com.inventario.telefonos"` a la etiqueta `<manifest>` y quite la línea `namespace` de `app/build.gradle`.

Si Google Maven está bloqueado o muy lento en su país, descomente los espejos (mirrors) de Aliyun que vienen preparados en `settings.gradle`.

## 5. Instalar el APK en los teléfonos

Esta app no se publica en la Play Store (Google rechaza apps de inventario con permiso de SMS); se instala directamente:

1. Copie el `app-debug.apk` al teléfono (cable, correo o Bluetooth).
2. Ábralo y acepte **“Instalar apps desconocidas” / “Fuentes desconocidas”** cuando el sistema lo pida.
3. Al primer arranque la app pedirá dos permisos: **Teléfono** (para leer número/IMEI) y **SMS** (para enviar). Acéptelos; sin ellos la app funciona igual pero con menos campos automáticos y sin el envío directo.

## 6. Configuración

En la pantalla principal, toque la franja **“Destinatario de los SMS…”** o el botón **“Configuración de envío”** (también está en el menú ⋮):

- **Número de teléfono de destino:** el teléfono del administrador o del equipo que recibe los inventarios. Es editable en cualquier momento y se guarda en la app.
- **Formato del mensaje:** Compacto (una línea, para procesar automático) o Detallado (varias líneas).

## 7. Integrar el lado receptor

La aplicación que recibe los SMS debe:

1. Filtrar los mensajes que empiezan por `INV|`.
2. Partir el texto por `|` e ignorar el primer trozo (`INV`).
3. Para cada trozo, partir por el primer `:` → clave y valor.
4. Con la clave (tabla del punto 3) crear o actualizar la ficha del teléfono (se sugiere usar el `IMEI` o el `TEL` como identificador único).

Pseudocódigo:

```
si texto.startsWith("INV|"):
    para trozo en texto.split("|")[1..]:
        (clave, valor) = trozo.split(":")   # solo la primera aparición de ":"
        ficha[clave] = valor
```

## 8. Seguridad y buenas prácticas

- **PIN y PUK de la SIM:** Android no los entrega a ninguna aplicación y deben escribirse a mano. Envíelos por SMS solo si el canal es confiable y, al registrarlos, guárdelos únicamente en el sistema de inventario; conviene borrar el hilo de SMS del teléfono después de enviarlo.
- El envío automático necesita saldo en la línea; una ficha en formato compacto con acentos suele ocupar entre 2 y 5 SMS (la app muestra la cantidad exacta antes de confirmar).
- Si el número del operador (`TEL`) viene vacío (común en SIM prepago), escríbalo manualmente una vez: la app lo conserva en el borrador.

## 9. Estructura del proyecto

```
InventarioTelefonos/
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/inventario/telefonos/
│       │   ├── MainActivity.kt          # Formulario y envío
│       │   ├── SettingsActivity.kt      # Número destino y formato
│       │   ├── PhoneInfoCollector.kt    # Datos automáticos del equipo
│       │   ├── MessageBuilder.kt        # Formato compacto / detallado del SMS
│       │   └── SmsSender.kt             # Envío (multiparte)
│       └── res/
│           ├── layout/                  # activity_main.xml, activity_settings.xml
│           ├── values/                  # strings.xml (español), themes, colors, arrays
│           ├── drawable/                # fondos de campos y botones
│           ├── menu/                    # menú de configuración
│           └── mipmap-*/                # iconos (5 densidades)
├── build.gradle / settings.gradle / gradle.properties
└── gradle/wrapper/  (gradlew y gradlew.bat incluidos)
```

## 10. Solución de problemas

| Problema | Solución |
|----------|----------|
| “Gradle wrapper not found / gradle-wrapper.jar missing” | Verifique que `gradle/wrapper/gradle-wrapper.jar` existe (viene incluido en el ZIP). |
| La sincronización falla al descargar dependencias | Descomente los espejos de Aliyun en `settings.gradle` y vuelva a sincronizar. |
| Denegué los permisos con “no volver a preguntar” | Ajustes → Aplicaciones → Inventario de Teléfonos → Permisos → activar Teléfono y SMS. |
| El IMEI/MAC vienen vacíos | Normal en Android 10+ por protección de privacidad; escríbalos a mano. |
| “Error al enviar” al pulsar Enviar | Verifique el número de destino en Configuración y que la línea tenga saldo. |
| Quiero cambiar el nombre o el paquete | Nombre: `app_name` en `strings.xml`. Paquete: `namespace` y `applicationId` en `app/build.gradle` (cámbielos en ambos). |
