package com.inventario.telefonos

/**
 * Construye el texto del SMS a partir de los datos del formulario.
 *
 * Formato compacto (recomendado): una sola linea con pares CLAVE:VALOR separados
 * por "|", pensado para que la aplicacion receptora lo interprete automaticamente:
 *
 *   INV|TRAB:...|CI:...|CARGO:...|TIPO:...|MARCA:...|MODELO:...|ANDV:...|TEL:...|
 *   IMEI:...|MAC:...|WIP:...|SIP:...|NET:...|MIN:...|MB:...|PIN:...|PUK:...
 *
 * Formato detallado: una linea por campo, comodo para que lo lea una persona.
 */
object MessageBuilder {

    const val PREFIJO = "INV"

    /** clave del formulario -> clave que viaja en el SMS compacto */
    private val CLAVES_COMPACTO = linkedMapOf(
        "trabajador" to "TRAB",
        "ci" to "CI",
        "cargo" to "CARGO",
        "tipo" to "TIPO",
        "marca" to "MARCA",
        "modelo" to "MODELO",
        "versionAndroid" to "ANDV",
        "telefono" to "TEL",
        "imei" to "IMEI",
        "mac" to "MAC",
        "wifiIp" to "WIP",
        "simIp" to "SIP",
        "internet" to "NET",
        "minutos" to "MIN",
        "megas" to "MB",
        "pin" to "PIN",
        "puk" to "PUK"
    )

    /** clave del formulario -> titulo legible para el formato detallado */
    private val TITULOS_DETALLADO = linkedMapOf(
        "trabajador" to "Trabajador",
        "ci" to "CI",
        "cargo" to "Cargo",
        "tipo" to "Tipo",
        "marca" to "Marca",
        "modelo" to "Modelo",
        "versionAndroid" to "Versión Android",
        "telefono" to "No. Teléfono",
        "imei" to "IMEI",
        "mac" to "MAC",
        "wifiIp" to "WiFi IP",
        "simIp" to "SIM IP",
        "internet" to "Internet",
        "minutos" to "Minutos",
        "megas" to "Megas",
        "pin" to "PIN SIM",
        "puk" to "PUK SIM"
    )

    fun construir(datos: Map<String, String>, formatoCompacto: Boolean): String =
        if (formatoCompacto) compacto(datos) else detallado(datos)

    /** Los valores no pueden romper el separador "|" ni contener saltos de linea. */
    private fun limpiar(valor: String?): String =
        (valor ?: "").replace("|", "/").replace("\n", " ").replace("\r", " ").trim()

    private fun compacto(datos: Map<String, String>): String {
        val sb = StringBuilder(PREFIJO)
        for ((claveDatos, claveSms) in CLAVES_COMPACTO) {
            sb.append('|').append(claveSms).append(':').append(limpiar(datos[claveDatos]))
        }
        return sb.toString()
    }

    private fun detallado(datos: Map<String, String>): String {
        val lineas = mutableListOf("$PREFIJO - Inventario de teléfono")
        for ((claveDatos, titulo) in TITULOS_DETALLADO) {
            lineas.add("$titulo: ${limpiar(datos[claveDatos])}")
        }
        return lineas.joinToString("\n")
    }
}
