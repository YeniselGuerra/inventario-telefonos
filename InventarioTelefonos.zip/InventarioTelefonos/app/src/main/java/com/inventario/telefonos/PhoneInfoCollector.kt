package com.inventario.telefonos

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.Locale

/**
 * Informacion del telefono que la app puede leer automaticamente.
 */
data class PhoneInfo(
    val marca: String,
    val modelo: String,
    val versionAndroid: String,
    val imei: String,
    val mac: String,
    val telefono: String,
    val wifiIp: String,
    val simIp: String,
    val tieneInternet: String
)

/**
 * Recolector de datos del equipo. Todo lo que falle o este prohibido por
 * Android se devuelve vacio ("") para que el usuario lo complete a mano
 * en el formulario.
 *
 * Limitaciones conocidas (proteccion de privacidad de Android):
 *  - Android 10+: el IMEI y la MAC real no son legibles por apps normales.
 *  - El PIN y el PUK de la SIM nunca son legibles por ninguna app.
 */
object PhoneInfoCollector {

    private const val MAC_FALSA = "02:00:00:00:00:00"

    fun puedeLeerTelefono(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED

    fun recolectar(context: Context): PhoneInfo {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val permiso = puedeLeerTelefono(context)

        val imei = try {
            if (permiso && tm != null) {
                when {
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O -> tm.imei
                    else -> @Suppress("DEPRECATION") tm.deviceId
                }
            } else null
        } catch (e: Exception) {
            null
        } ?: ""

        val telefono = try {
            if (permiso && tm != null) tm.line1Number else null
        } catch (e: Exception) {
            null
        } ?: ""

        return PhoneInfo(
            marca = Build.MANUFACTURER?.trim() ?: "",
            modelo = Build.MODEL?.trim() ?: "",
            versionAndroid = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            imei = imei,
            mac = macWifi() ?: "",
            telefono = telefono,
            wifiIp = ipDeInterfaz(listOf("wlan", "eth")) ?: "",
            simIp = ipDeInterfaz(listOf("rmnet", "ccmni", "usbnet", "v4-rmnet")) ?: "",
            tieneInternet = if (hayInternet(context)) "SI" else "NO"
        )
    }

    /** ¿Hay una conexion con salida a Internet disponible? */
    private fun hayInternet(context: Context): Boolean = try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val red = cm?.activeNetwork
        val caps = red?.let { cm.getNetworkCapabilities(it) }
        caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (e: Exception) {
        false
    }

    /** Busca una direccion IPv4 entre las interfaces cuyo nombre empiece por alguno de los prefijos. */
    private fun ipDeInterfaz(prefijos: List<String>): String? = try {
        val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
        for (nif in Collections.list(interfaces)) {
            val nombre = nif.name?.lowercase(Locale.US) ?: continue
            if (prefijos.any { nombre.startsWith(it) }) {
                for (addr in Collections.list(nif.inetAddresses)) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) return addr.hostAddress
                }
            }
        }
        null
    } catch (e: Exception) {
        null
    }

    /** MAC de la interfaz WiFi. En Android 10+ el sistema devuelve una MAC aleatoria o ninguna. */
    private fun macWifi(): String? = try {
        val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
        for (nif in Collections.list(interfaces)) {
            val nombre = nif.name?.lowercase(Locale.US) ?: continue
            if (nombre.startsWith("wlan")) {
                val mac = nif.hardwareAddress ?: continue
                if (mac.size == 6) {
                    val texto = mac.joinToString(":") { String.format(Locale.US, "%02X", it) }
                    if (texto != MAC_FALSA) return texto
                }
            }
        }
        null
    } catch (e: Exception) {
        null
    }
}
