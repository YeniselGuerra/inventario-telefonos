package com.inventario.telefonos

import android.content.Context
import android.os.Build
import android.telephony.SmsManager

/**
 * Envio de SMS con SmsManager. Los mensajes largos se dividen automaticamente
 * en varias partes (sendMultipartTextMessage) y llegan al destinatario como
 * un solo mensaje.
 */
object SmsSender {

    private fun manager(context: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION") SmsManager.getDefault()
        }

    /** Cantidad de partes en que se dividira el mensaje (1 SMS ≈ 160 caracteres sin acentos, 70 con acentos). */
    fun partes(context: Context, mensaje: String): Int = try {
        manager(context).divideMessage(mensaje).size
    } catch (e: Exception) {
        1
    }

    /** Envia el mensaje. Requiere el permiso SEND_SMS concedido. Devuelve la cantidad de SMS enviados. */
    fun enviar(context: Context, destino: String, mensaje: String): Int {
        val sm = manager(context)
        val partesMensaje = sm.divideMessage(mensaje)
        if (partesMensaje.size <= 1) {
            sm.sendTextMessage(destino, null, mensaje, null, null)
        } else {
            sm.sendMultipartTextMessage(destino, null, partesMensaje, null, null)
        }
        return partesMensaje.size
    }
}
