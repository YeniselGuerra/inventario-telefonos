package com.inventario.telefonos

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        const val PREFS_CONFIG = "config"
        const val KEY_DESTINO = "numero_destino"
        const val KEY_COMPACTO = "formato_compacto"
        private const val PREFS_BORRADOR = "borrador"
        private const val CODIGO_PERMISOS = 100
    }

    private lateinit var tvDestino: TextView
    private lateinit var etTrabajador: EditText
    private lateinit var etCi: EditText
    private lateinit var etCargo: EditText
    private lateinit var spTipo: Spinner
    private lateinit var etMarca: EditText
    private lateinit var etModelo: EditText
    private lateinit var etVersionAndroid: EditText
    private lateinit var etTelefono: EditText
    private lateinit var etImei: EditText
    private lateinit var etMac: EditText
    private lateinit var etWifiIp: EditText
    private lateinit var etSimIp: EditText
    private lateinit var spInternet: Spinner
    private lateinit var etMinutos: EditText
    private lateinit var etMegas: EditText
    private lateinit var etPin: EditText
    private lateinit var etPuk: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        enlazarVistas()
        cargarBorrador()
        pedirPermisos()
        actualizarAutomaticos()

        findViewById<Button>(R.id.btnActualizar).setOnClickListener {
            actualizarAutomaticos()
            Toast.makeText(this, R.string.toast_actualizado, Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnEnviar).setOnClickListener { enviarSms() }
        findViewById<Button>(R.id.btnAbrirSms).setOnClickListener { abrirAppSms() }
        findViewById<Button>(R.id.btnCopiar).setOnClickListener { copiarMensaje() }
        findViewById<Button>(R.id.btnConfig).setOnClickListener { abrirConfiguracion() }
        tvDestino.setOnClickListener { abrirConfiguracion() }
    }

    override fun onResume() {
        super.onResume()
        mostrarDestino()
    }

    override fun onPause() {
        super.onPause()
        guardarBorrador()
    }

    private fun enlazarVistas() {
        tvDestino = findViewById(R.id.tvDestino)
        etTrabajador = findViewById(R.id.etTrabajador)
        etCi = findViewById(R.id.etCi)
        etCargo = findViewById(R.id.etCargo)
        spTipo = findViewById(R.id.spTipo)
        etMarca = findViewById(R.id.etMarca)
        etModelo = findViewById(R.id.etModelo)
        etVersionAndroid = findViewById(R.id.etVersionAndroid)
        etTelefono = findViewById(R.id.etTelefono)
        etImei = findViewById(R.id.etImei)
        etMac = findViewById(R.id.etMac)
        etWifiIp = findViewById(R.id.etWifiIp)
        etSimIp = findViewById(R.id.etSimIp)
        spInternet = findViewById(R.id.spInternet)
        etMinutos = findViewById(R.id.etMinutos)
        etMegas = findViewById(R.id.etMegas)
        etPin = findViewById(R.id.etPin)
        etPuk = findViewById(R.id.etPuk)
    }

    /** Pide los permisos peligrosos: envio de SMS y lectura de datos del telefono. */
    private fun pedirPermisos() {
        val pedidos = arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_PHONE_NUMBERS
        )
        val faltantes = pedidos.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (faltantes.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, faltantes.toTypedArray(), CODIGO_PERMISOS)
        }
    }

    override fun onRequestPermissionsResult(
        codigo: Int,
        permisos: Array<out String>,
        resultados: IntArray
    ) {
        super.onRequestPermissionsResult(codigo, permisos, resultados)
        if (codigo == CODIGO_PERMISOS) {
            if (resultados.any { it == PackageManager.PERMISSION_GRANTED }) {
                actualizarAutomaticos()
            } else {
                Toast.makeText(this, R.string.aviso_permisos, Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Llena los campos que el telefono permite leer automaticamente. */
    private fun actualizarAutomaticos() {
        val info = PhoneInfoCollector.recolectar(this)

        etMarca.setText(info.marca)
        etModelo.setText(info.modelo)
        etVersionAndroid.setText(info.versionAndroid)
        etWifiIp.setText(info.wifiIp.ifBlank { "-" })
        etSimIp.setText(info.simIp.ifBlank { "-" })
        spInternet.setSelection(if (info.tieneInternet == "SI") 0 else 1)

        // Estos tres solo se autollenan si el usuario no escribio ya un valor.
        if (info.telefono.isNotBlank() && etTelefono.text.isNullOrBlank()) {
            etTelefono.setText(info.telefono)
        }
        if (info.imei.isNotBlank() && etImei.text.isNullOrBlank()) {
            etImei.setText(info.imei)
        }
        if (info.mac.isNotBlank() && etMac.text.isNullOrBlank()) {
            etMac.setText(info.mac)
        }
    }

    /** Reune los campos del formulario en un mapa clave -> valor. */
    private fun mapaDatos(): Map<String, String> = mapOf(
        "trabajador" to etTrabajador.text.toString().trim(),
        "ci" to etCi.text.toString().trim(),
        "cargo" to etCargo.text.toString().trim(),
        "tipo" to (spTipo.selectedItem?.toString() ?: ""),
        "marca" to etMarca.text.toString().trim(),
        "modelo" to etModelo.text.toString().trim(),
        "versionAndroid" to etVersionAndroid.text.toString().trim(),
        "telefono" to etTelefono.text.toString().trim(),
        "imei" to etImei.text.toString().trim(),
        "mac" to etMac.text.toString().trim(),
        "wifiIp" to etWifiIp.text.toString().trim(),
        "simIp" to etSimIp.text.toString().trim(),
        "internet" to (spInternet.selectedItem?.toString() ?: ""),
        "minutos" to etMinutos.text.toString().trim(),
        "megas" to etMegas.text.toString().trim(),
        "pin" to etPin.text.toString().trim(),
        "puk" to etPuk.text.toString().trim()
    )

    private fun destinoActual(): String =
        getSharedPreferences(PREFS_CONFIG, MODE_PRIVATE).getString(KEY_DESTINO, "") ?: ""

    private fun formatoCompacto(): Boolean =
        getSharedPreferences(PREFS_CONFIG, MODE_PRIVATE).getBoolean(KEY_COMPACTO, true)

    private fun mensajeActual(): String =
        MessageBuilder.construir(mapaDatos(), formatoCompacto())

    private fun mostrarDestino() {
        val destino = destinoActual()
        tvDestino.text = getString(
            R.string.destino_actual,
            if (destino.isBlank()) getString(R.string.sin_configurar) else destino
        )
    }

    private fun abrirConfiguracion() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun enviarSms() {
        val destino = destinoActual()
        if (TextUtils.isEmpty(destino)) {
            Toast.makeText(this, R.string.toast_sin_destino, Toast.LENGTH_LONG).show()
            abrirConfiguracion()
            return
        }
        val mensaje = mensajeActual()
        val cantidad = SmsSender.partes(this, mensaje)

        AlertDialog.Builder(this)
            .setTitle(R.string.confirmar_titulo)
            .setMessage(getString(R.string.confirmar_mensaje, destino, cantidad.toString(), mensaje))
            .setPositiveButton(R.string.btn_confirmar_enviar) { _, _ -> enviarConfirmado(destino, mensaje) }
            .setNegativeButton(R.string.btn_cancelar, null)
            .show()
    }

    private fun enviarConfirmado(destino: String, mensaje: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pedirPermisos()
            return
        }
        try {
            val cantidad = SmsSender.enviar(this, destino, mensaje)
            Toast.makeText(this, getString(R.string.toast_enviado, cantidad), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.toast_error_envio, e.message ?: "?"), Toast.LENGTH_LONG).show()
        }
    }

    /** Abre la app de mensajeria con el mensaje ya redactado (no necesita permisos). */
    private fun abrirAppSms() {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + destinoActual()))
        intent.putExtra("sms_body", mensajeActual())
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.error_app_sms, Toast.LENGTH_LONG).show()
        }
    }

    private fun copiarMensaje() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(getString(R.string.app_name), mensajeActual()))
        Toast.makeText(this, R.string.toast_copiado, Toast.LENGTH_SHORT).show()
    }

    // ---------- Borrador local (no se pierde lo escrito al cerrar la app) ----------

    private fun guardarBorrador() {
        getSharedPreferences(PREFS_BORRADOR, MODE_PRIVATE).edit()
            .putString("trabajador", etTrabajador.text.toString())
            .putString("ci", etCi.text.toString())
            .putString("cargo", etCargo.text.toString())
            .putInt("tipo", spTipo.selectedItemPosition)
            .putString("telefono", etTelefono.text.toString())
            .putString("imei", etImei.text.toString())
            .putString("mac", etMac.text.toString())
            .putInt("internet", spInternet.selectedItemPosition)
            .putString("minutos", etMinutos.text.toString())
            .putString("megas", etMegas.text.toString())
            .putString("pin", etPin.text.toString())
            .putString("puk", etPuk.text.toString())
            .apply()
    }

    private fun cargarBorrador() {
        val p = getSharedPreferences(PREFS_BORRADOR, MODE_PRIVATE)
        etTrabajador.setText(p.getString("trabajador", ""))
        etCi.setText(p.getString("ci", ""))
        etCargo.setText(p.getString("cargo", ""))
        spTipo.setSelection(p.getInt("tipo", 0))
        etTelefono.setText(p.getString("telefono", ""))
        etImei.setText(p.getString("imei", ""))
        etMac.setText(p.getString("mac", ""))
        spInternet.setSelection(p.getInt("internet", 0))
        etMinutos.setText(p.getString("minutos", ""))
        etMegas.setText(p.getString("megas", ""))
        etPin.setText(p.getString("pin", ""))
        etPuk.setText(p.getString("puk", ""))
    }

    // ---------- Menu ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        when (item.itemId) {
            R.id.accion_config -> {
                abrirConfiguracion()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
}
