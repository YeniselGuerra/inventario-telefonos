package com.inventario.telefonos

import android.os.Bundle
import android.text.TextUtils
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Pantalla de configuracion: numero de telefono de destino de los SMS y
 * formato del mensaje. Todo se guarda en las preferencias de la app.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var etDestino: EditText
    private lateinit var spFormato: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        etDestino = findViewById(R.id.etDestino)
        spFormato = findViewById(R.id.spFormato)

        val prefs = getSharedPreferences(MainActivity.PREFS_CONFIG, MODE_PRIVATE)
        etDestino.setText(prefs.getString(MainActivity.KEY_DESTINO, ""))
        spFormato.setSelection(if (prefs.getBoolean(MainActivity.KEY_COMPACTO, true)) 0 else 1)

        findViewById<Button>(R.id.btnGuardar).setOnClickListener { guardar() }
    }

    private fun guardar() {
        val destino = etDestino.text.toString().trim()
        if (TextUtils.isEmpty(destino)) {
            Toast.makeText(this, R.string.toast_falta_numero, Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences(MainActivity.PREFS_CONFIG, MODE_PRIVATE).edit()
            .putString(MainActivity.KEY_DESTINO, destino)
            .putBoolean(MainActivity.KEY_COMPACTO, spFormato.selectedItemPosition == 0)
            .apply()
        Toast.makeText(this, R.string.toast_guardado, Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
}
